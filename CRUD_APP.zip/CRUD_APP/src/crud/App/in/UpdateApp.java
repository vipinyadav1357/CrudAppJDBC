package crud.App.in;

import crud.jdbcUtil.in.JdbcUtil;

import java.io.IOException;
import java.sql.Connection;
import java.sql.PreparedStatement;
import java.sql.SQLException;
import java.util.Scanner;

public class UpdateApp {
    private UpdateApp(){

    }
    public static void Update()throws SQLException, IOException {
        Scanner input = new Scanner(System.in);
        Connection connection;
        PreparedStatement preparedStatement=null;
        int rowaffect=0;
        //making connection
        connection=JdbcUtil.getConnection();
        if (connection!=null){
            preparedStatement=connection.prepareStatement("update student set sname= ?,sage= ?,saddress= ? where sid = ?");
        }
        System.out.println("--Enter your Info For Update--");
        if(preparedStatement!=null){
            System.out.println("--Enter ID--");
            int sid=input.nextInt();
            System.out.println("--Enter SNAME--");
            String sname=input.next();
            System.out.println("--Enter SAGE--");
            int sage=input.nextInt();
            System.out.println("--Enter SADDRESS--");
            String saddress=input.next();
            //Injecting
            preparedStatement.setInt(4,sid);
            preparedStatement.setString(1,sname);
            preparedStatement.setInt(2,sage);
            preparedStatement.setString(3,saddress);
            rowaffect= preparedStatement.executeUpdate();
            if(rowaffect==1){
                System.out.println("Record Updated Successfully!");
            }else{
                System.out.println("Record Not Updated");
            }
        }
        JdbcUtil.cleanUp(connection,preparedStatement,null);
    }
}
