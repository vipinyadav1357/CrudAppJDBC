package crud.App.in;

import crud.jdbcUtil.in.JdbcUtil;

import java.io.IOException;
import java.sql.Connection;
import java.sql.PreparedStatement;
import java.sql.SQLException;
import java.util.Scanner;

public class InsertApp {
    private InsertApp(){

    }
    public static void Insert()throws SQLException, IOException {
        Scanner input = new Scanner(System.in);
        Connection connection;
        PreparedStatement preparedStatement=null;
        int rowaffect=0;
        //making connection
        connection=JdbcUtil.getConnection();
        if (connection!=null){
            preparedStatement=connection.prepareStatement("insert into student(`sid`,`sname`,`sage`,`saddress`)values(?,?,?,?)");
        }
        System.out.println("--Enter your Info--");
        if(preparedStatement!=null){
            System.out.println("--Enter ID--");
            int sid=input.nextInt();
            System.out.println("--Enter SNAME--");
            String sname=input.next();
            System.out.println("--Enter SAGE--");
            int sage=input.nextInt();
            System.out.println("--Enter SADDRESS--");
            String saddress=input.next();
            //Injecting
            preparedStatement.setInt(1,sid);
            preparedStatement.setString(2,sname);
            preparedStatement.setInt(3,sage);
            preparedStatement.setString(4,saddress);
           rowaffect= preparedStatement.executeUpdate();
            if(rowaffect==1){
                System.out.println("Record Inserted Successfully!");
            }else{
                System.out.println("Record Not Inserted");
            }
        }
        JdbcUtil.cleanUp(connection,preparedStatement,null);
    }
}
