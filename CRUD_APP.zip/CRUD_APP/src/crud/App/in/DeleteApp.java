package crud.App.in;

import crud.jdbcUtil.in.JdbcUtil;

import java.io.IOException;
import java.sql.Connection;
import java.sql.PreparedStatement;
import java.sql.SQLException;
import java.util.Scanner;

public class DeleteApp {
    private DeleteApp(){

    }
    public static void Delete()throws SQLException, IOException {
        Scanner input = new Scanner(System.in);
        Connection connection;
        PreparedStatement preparedStatement=null;
        int rowaffect=0;
        //making connection
        connection= JdbcUtil.getConnection();
        if (connection!=null){
            preparedStatement=connection.prepareStatement("delete from student where sid=?");
        }
        System.out.println("--Enter your Info For Update--");
        if(preparedStatement!=null){
            System.out.println("--Enter ID--");
            int sid=input.nextInt();
            //Injecting
            preparedStatement.setInt(1,sid);
            rowaffect= preparedStatement.executeUpdate();
            if(rowaffect==1){
                System.out.println("Record Deleted Successfully!");
            }else{
                System.out.println("Record Not Available");
            }
        }
        JdbcUtil.cleanUp(connection,preparedStatement,null);
    }
}
