package crud.App.in;

import java.io.IOException;
import java.sql.SQLException;
import java.util.Scanner;

public class MainApp {
    public static void main(String[] args) throws SQLException, IOException{
        Scanner sc=new Scanner(System.in);
        System.out.println("=========================================\n" +
                "Menu for performing CRUD Operation\n" +
                "Press 1 for INSERT Operation\n"+
                "Press 2 for SELECT Operation\n"+
                "Press 3 for UPDATE Operation\n"+
                "Press 4 for DELETE Operation\n"+
                "Press any key to Exit the Application\n"+
                "=========================================");
        int choice=sc.nextInt();
        while (choice>=1&&choice<=5){
            if (choice == 1) {
                InsertApp.Insert();
            } else if (choice==2) {
                SelectApp.Select();
            } else if (choice==3) {
                UpdateApp.Update();
            } else if (choice==4) {
                DeleteApp.Delete();
            }else{
                System.exit(0);
            }
            System.out.println("=========================================\n" +
                    "Menu for performing CRUD Operation\n" +
                    "Press 1 for INSERT Operation\n"+
                    "Press 2 for SELECT Operation\n"+
                    "Press 3 for UPDATE Operation\n"+
                    "Press 4 for DELETE Operation\n"+
                    "Press any key to Exit the Application\n"+
                    "=========================================");
            choice=sc.nextInt();
        }
    }
}
