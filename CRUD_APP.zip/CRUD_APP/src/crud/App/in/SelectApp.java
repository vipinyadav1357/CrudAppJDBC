package crud.App.in;

import crud.jdbcUtil.in.JdbcUtil;

import java.io.IOException;
import java.sql.Connection;
import java.sql.PreparedStatement;
import java.sql.ResultSet;
import java.sql.SQLException;
import java.util.Scanner;
public class SelectApp {
    private SelectApp(){

    }

    public static void Select()throws SQLException, IOException {
        Scanner input = new Scanner(System.in);
        Connection connection;
        PreparedStatement preparedStatement=null;
        ResultSet resultSet=null;
        //making connection
        connection= JdbcUtil.getConnection();
        if (connection!=null){
            preparedStatement=connection.prepareStatement("select sid, sname, sage, saddress from student where sid= ?");
        }
        System.out.println("--Enter your Info--");
        if(preparedStatement!=null) {
            System.out.println("--Enter ID--");
            int sid = input.nextInt();
            //Injecting
            preparedStatement.setInt(1, sid);
            resultSet = preparedStatement.executeQuery();
        }
        if(resultSet!=null){
            if(resultSet.next()){
                System.out.println("Sid\t Sname\t   Sage\t Saddress");
                System.out.println(resultSet.getInt(1)+"\t"+resultSet.getString(2)+"\t\t"+resultSet.getInt(3)+"\t\t"+resultSet.getString(4));
            }else{
                System.out.println("Record Not Found");
            }
        }
        JdbcUtil.cleanUp(connection,preparedStatement,null);
    }
    }
